﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DefaultBO;
using Microsoft.ApplicationBlocks.Data;

namespace DefaultDAL
{
    public class defaultdal
    {
		defaultbo lbo = new defaultbo();

		private string ConnectionString;

		public defaultdal()
		{
			ConnectionString = ConfigurationManager.ConnectionStrings["defaultConnection"].ToString();
		}

		//1. Insert Registration
		public int InsertCoins(defaultbo ebo)
		{
			string insert = "PR_COINS_INSERT";
			using (SqlConnection con = new SqlConnection(ConnectionString))
			{
				using (SqlCommand cmd = new SqlCommand(insert, con))
				{
					con.Open();
					try
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@Item", ebo.Item);
						cmd.Parameters.AddWithValue("@Price", ebo.Price);
						cmd.Parameters.AddWithValue("@Created", System.DateTime.Now);						
						return cmd.ExecuteNonQuery();
					}
					catch (Exception)
					{
						return -1;
					}
					finally
					{
						con.Close();
						con.Dispose();
					}
				}
			}
		}

		//2. Get Details Coiuns
		public DataSet GetCoins()
		{
			using (SqlConnection con = new SqlConnection(ConnectionString))
			{
				try
				{
					DataSet dsLeaveTypes = new DataSet();
					dsLeaveTypes = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "PR_ID_BY_SELECT");
					return dsLeaveTypes;
				}
				catch (Exception ex)
				{
					return null;
				}
				finally
				{
					con.Close();
					con.Dispose();
				}
			}
		}

		//3. Update

		public int InsertUpdateCoins(defaultbo ebo)
		{
			string insert = "PR_COINS_INSERT";
			using (SqlConnection con = new SqlConnection(ConnectionString))
			{
				using (SqlCommand cmd = new SqlCommand(insert, con))
				{
					con.Open();
					try
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@Id", ebo.Id);
						cmd.Parameters.AddWithValue("@Item", ebo.Id);
						cmd.Parameters.AddWithValue("@Price", ebo.Price);
						cmd.Parameters.AddWithValue("@Created", System.DateTime.Now);
						return cmd.ExecuteNonQuery();
					}
					catch (Exception)
					{
						return -1;
					}
					finally
					{
						con.Close();
						con.Dispose();
					}
				}
			}
		}
	}
}
