﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DefaultBO;
using DefaultBAL;

namespace SampleTest
{
	public partial class Items : System.Web.UI.Page
	{
		defaultbal pdal = new defaultbal();
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			defaultbo pbo = new defaultbo();
			pbo.Item = txtItem.Text.Trim();
			pbo.Price = txtPrice.Text.Trim();			
			int result = pdal.InsertCoins(pbo);
			if (result == 1)
			{
				ClientScript.RegisterStartupScript(GetType(), "Hi", "<script> alert('Coins Added Successfully');</script>");
				Response.Redirect("Dashboard.aspx");
			}
			else
			{
				llblmsg.Text = "Problem in Insertion";
			}
		}
	}
}