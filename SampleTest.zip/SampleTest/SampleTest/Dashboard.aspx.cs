﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DefaultBAL;
using DefaultBO;

namespace SampleTest
{
	public partial class Dashboard : System.Web.UI.Page
	{
		defaultbal BAl = new defaultbal();
		defaultbo ibo = new defaultbo();
		protected void Page_Load(object sender, EventArgs e)
		{
			bindCoins();
		}

		private void bindCoins()
		{
			gvCoins.DataSource = BAl.GetCoins();
			gvCoins.DataBind();
		}

		protected void gvCoins_RowUpdating(object sender, GridViewUpdateEventArgs e)
		{
			GridViewRow gvRow = gvCoins.Rows[e.RowIndex];
			TextBox ER = (TextBox)gvRow.FindControl("txtItem");
			TextBox EW = (TextBox)gvRow.FindControl("txtPrice");			
			string Item = ER.Text;
			string Price = EW.Text;
			ibo.Item = Item;
			ibo.Price = Price;
			string Id = gvCoins.DataKeys[e.RowIndex].Value.ToString();
			int EmpId = Convert.ToInt32(Id);
			ibo.Id = EmpId;
			int insert = BAl.InsertUpdateCoins(ibo);
			if (insert > 0)
			{
				this.ClientScript.RegisterStartupScript(this.GetType(), "Startupalert", "alert('Details Updated Successfully');", true);
				gvCoins.EditIndex = -1;
				bindCoins();
			}
			else
			{
				this.ClientScript.RegisterStartupScript(this.GetType(), "Startupalert", "alert('Problem in updation');", true);
			}
		}

		protected void gvCoins_RowEditing1(object sender, GridViewEditEventArgs e)
		{
			gvCoins.EditIndex = e.NewEditIndex;
			bindCoins();
		}

		protected void gvCoins_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
		{
			e.Cancel = true;
			gvCoins.EditIndex = -1;
			bindCoins();
		}

		protected void gvCoins_PageIndexChanging1(object sender, GridViewPageEventArgs e)
		{
			gvCoins.PageIndex = e.NewPageIndex;
			gvCoins.DataBind();
			bindCoins();
		}
	}
}