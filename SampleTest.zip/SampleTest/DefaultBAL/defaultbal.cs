﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DefaultBO;
using DefaultDAL;

namespace DefaultBAL
{
    public class defaultbal
    {
		defaultdal ddal = new defaultdal();

		public DataSet GetCoins()
		{
			return ddal.GetCoins();
		}

		public int InsertCoins(defaultbo dbo)
		{
			return ddal.InsertCoins(dbo);
		}

		public int InsertUpdateCoins(defaultbo ebo)
		{
			return ddal.InsertUpdateCoins(ebo);
		}
	}
}
